// import React from 'react'
// import './header.css'
// import { MdDashboard, MdOutlineRestaurantMenu } from 'react-icons/md'
// import { Link } from 'react-router-dom'
// import { FaEdit, FaUserAlt } from 'react-icons/fa'
// import { GrLogout } from 'react-icons/gr'
// import { GiFoodTruck } from 'react-icons/gi'



// function Header() {
//   return (
//     <>
//     <div className="abs">
//     <div className="vw">
//       <div className="flex">
//             <div className="nav">
//                 <h3>Home</h3>
//                  <Link to={'/dash'}>  <a className='a' href="#"><MdDashboard /> Dashboard</a></Link> 
//             <Link to={"/add"}> <a  className='a' href="#"> <MdOutlineRestaurantMenu /> Add Food</a></Link>
//             <Link to={"/edit"}> <a className='a' href="#"> <FaEdit /> Edit Food</a></Link>
//             <Link to={"/userr"}> <a className='a' href="#"> <FaUserAlt /> User</a></Link>
//             <Link to={"/order"}> <a className='a'href="#"> <GiFoodTruck /> Order Food</a></Link>
//             <Link to={"/log"}> <a className='a'href="#"> <GrLogout /> LogOut</a></Link>

//             </div>
//         </div>
//     </div>
//     </div>
//     </>
//   )
// }

// export default Header

