// import React from 'react'
// import {  Route, Routes } from 'react-router-dom'
// import AdminLogin from './AdminLogin'
// import ForgotPass from './ForgotPass'
// import UserLogin from './UserLogin'
// import Register from './Register'

// function Foodrouter() {
//   return (
//     <>
//     <Routes>
//         {/* <Route path={"/"} element={<ForgotPass/>}/> */}
//         {/* <Route path={"/admin"} element={<AdminLogin/>}/>
//         <Route path={"/user"} element={<UserLogin/>}/>
//         <Route path={"/reg"} element={<Register/>}/> */}
//     </Routes>
//     {/* <ForgotPass/> */}
// {/* <AdminLogin/>
// <UserLogin/>
// <Register/> */}
//     </>
//   )
// }

// export default Foodrouter